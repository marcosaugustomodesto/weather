package com.crossover.trial.weather.exceptions;

/**
 * An internal exception marker
 */
public class WeatherException extends Exception {
               
}
